import math
from random import randint
secret_number = randint(1,10)
guess_count = 0
guess_limit = 3

while guess_count < guess_limit:

    guess = int(input("Guess number (1-10): "))
    guess_count += 1

    if guess == secret_number:
        print("Correct guess!")
        break

    else:
        print("Incorrect guess!")
print("Game ended!")
input("Click enter to end game")

